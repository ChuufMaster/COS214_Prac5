#include "CustomerReadyState.h"
/// @brief still needs to be implemented but part of the state design pattern.
CustomerReadyState::CustomerReadyState() {}

CustomerReadyState::~CustomerReadyState() {}
