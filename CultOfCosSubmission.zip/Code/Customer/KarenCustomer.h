#ifndef KARENCUSTOMER_H
#define KARENCUSTOMER_H
#include "Customer.h"

class KarenCustomer : public Customer {

public:
  int customerHappiness = 5;
  KarenCustomer();
};

#endif
