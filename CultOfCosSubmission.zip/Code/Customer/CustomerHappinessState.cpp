#include "CustomerHappinessState.h"
/// @brief still needs to be implemented but part of the state design pattern.
CustomerHappinessState::CustomerHappinessState() {}

CustomerHappinessState::~CustomerHappinessState() {}
