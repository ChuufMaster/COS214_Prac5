#include "Chef.h"

int Chef::getCookingTime() { return this->_cookingTime; }

void Chef::setCookingTime(int cookingTime) { this->_cookingTime = cookingTime; }
