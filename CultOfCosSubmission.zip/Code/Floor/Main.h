#ifndef MAIN_H
#define MAIN_H

class Main {};

#endif
