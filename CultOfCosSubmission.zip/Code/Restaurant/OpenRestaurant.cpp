#include "OpenRestaurant.h"
#include "Command.h"

OpenRestaurant::OpenRestaurant() {}

void OpenRestaurant::executeRestaurant() { restaurant.isOpen = true; }
