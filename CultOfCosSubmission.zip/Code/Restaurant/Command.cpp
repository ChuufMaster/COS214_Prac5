#include "Command.h"

Command::Command() {}