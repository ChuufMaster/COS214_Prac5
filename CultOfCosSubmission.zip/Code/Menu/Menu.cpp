#include "Menu.h"
/// @brief this is the base class of the design and is the interface for
/// menuItem.
Menu::~Menu() {}

Menu::Menu() {}
